// =============================================================================
// JS/X-SHORTCODES-SITE-HEAD.JS
// -----------------------------------------------------------------------------
// Site specific functionality needed in <head> element.
// =============================================================================

// =============================================================================
// TABLE OF CONTENTS
// -----------------------------------------------------------------------------
//   01. Imports
// =============================================================================

// Imports
// =============================================================================

// @codekit-append "site/vendor/backstretch.js"
// @codekit-append "site/vendor/modernizr.js"
// @codekit-append "site/vendor/fittext.js"
// @codekit-append "site/vendor/slick.js"

// =include "site/vendor/backstretch.js"
// =include "site/vendor/modernizr.js"
// =include "site/vendor/fittext.js"
// =include "site/vendor/slick.js"