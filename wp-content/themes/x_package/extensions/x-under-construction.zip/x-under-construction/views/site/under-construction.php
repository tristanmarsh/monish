<?php

// =============================================================================
// VIEWS/SITE/TERMS-OF-USE.PHP
// -----------------------------------------------------------------------------
// Plugin site output.
// =============================================================================

// =============================================================================
// TABLE OF CONTENTS
// -----------------------------------------------------------------------------
//   01. Require Options
//   02. Output
// =============================================================================

// Require Options
// =============================================================================

require( X_UNDER_CONSTRUCTION_PATH . '/functions/options.php' );



// Output
// =============================================================================

$facebook    = $x_under_construction_facebook;
$twitter     = $x_under_construction_twitter;
$google_plus = $x_under_construction_google_plus;
$instagram   = $x_under_construction_instagram;

?>

<div class="x-under-construction-overlay">
  <div class="x-under-construction-wrap-outer">
    <div class="x-under-construction-wrap-inner">
      <div class="x-under-construction">

        <h1><?php echo $x_under_construction_heading; ?></h1>
        <h2><?php echo $x_under_construction_subheading; ?></h2>

        <?php if ( $x_under_construction_date != '' ) : ?>

          <div class="x-under-construction-countdown cf">
            <span class="days"></span>
            <span class="hours"></span>
            <span class="minutes"></span>
            <span class="seconds"></span>
          </div>

          <script type="text/javascript">
            jQuery(document).ready(function($) {
              $('.x-under-construction-countdown').countdown('<?php echo $x_under_construction_date; ?>',
                function(e) {

                  var $this = $(this);

                  $this.find('.days').text(e.strftime('%-D Days'));
                  $this.find('.hours').text(e.strftime('%-H Hours'));
                  $this.find('.minutes').text(e.strftime('%-M Minutes'));
                  $this.find('.seconds').text(e.strftime('%-S Seconds'));

                }
              );
            });
          </script>

        <?php endif; ?>

        <?php if ( $facebook || $twitter || $google_plus || $instagram ) : ?>

          <div class="x-under-construction-social">
            <?php if ( $facebook )    : ?><a href="<?php echo $facebook ?>" target="_blank"><i class="x-icon x-icon-facebook-square"></i></a><?php endif; ?>
            <?php if ( $twitter )     : ?><a href="<?php echo $twitter ?>" target="_blank"><i class="x-icon x-icon-twitter-square"></i></a><?php endif; ?>
            <?php if ( $google_plus ) : ?><a href="<?php echo $google_plus ?>" target="_blank"><i class="x-icon x-icon-google-plus-square"></i></a><?php endif; ?>
            <?php if ( $instagram )   : ?><a href="<?php echo $instagram ?>" target="_blank"><i class="x-icon x-icon-instagram"></i></a><?php endif; ?>
          </div>

        <?php endif; ?>

      </div>
    </div>
  </div>
</div>